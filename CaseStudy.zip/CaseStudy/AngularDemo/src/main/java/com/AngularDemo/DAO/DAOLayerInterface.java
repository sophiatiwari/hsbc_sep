package com.AngularDemo.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.InstagramUser;

@Repository
public interface DAOLayerInterface {
	
	int createProfileDAO ( InstagramUser iu );

	int deleteProfileDAO ( String user );
	
	int updateProfileDAO ( InstagramUser iu );
	
	List <InstagramUser> viewAllProfileDAO ();

}
