package com.AngularDemo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.InstagramUser;

@Repository
public class DAOLayer implements DAOLayerInterface {

	@Override
	public int createProfileDAO (InstagramUser iu) {
		
		try {
			
			// load driver
			
			Class.forName ( "org.apache.derby.jdbc.EmbeddedDriver" );
			
			// get connection to database
			
			Connection con = DriverManager.getConnection ( "jdbc:derby:d:/database/instagram", "ashutosh", "4159" );
			
			// prepare query
			
			PreparedStatement ps = con.prepareStatement ( "INSERT INTO InstagramUser VALUES (?,?,?,?,?)" );
			
			ps.setString ( 1, iu.getName() );
			ps.setString ( 2, iu.getPassword() );
			
			ps.setString ( 3, iu.getEmail() );
			ps.setString ( 4, iu.getAddress() );
			
			ps.setString ( 5, "2020-09-27");
			
			// execute query
			
			if ( ps.executeUpdate () > 0 ) {
				
				return 1;
			}
		
		}
		
		catch ( ClassNotFoundException | SQLException sql ) {
			
			sql.printStackTrace ();
		}
		
		return 0;
	}

	@Override
	public int deleteProfileDAO ( String name ) {
		
		// deleting profile from database
		
		try {
		
			// load driver
			
			Class.forName ( "org.apache.derby.jdbc.EmbeddedDriver" );
							
			// get connection to database
						
			Connection con = DriverManager.getConnection ( "jdbc:derby:d:/database/instagram", "ashutosh", "4159" );
							
			PreparedStatement ps = con.prepareStatement ( "DELETE FROM InstagramUser WHERE NAME = '" + name + "'");	// delete record
			
			if ( ps.executeUpdate () > 0 ) {
				
				return 1;
			}			
			
		
		}catch ( ClassNotFoundException | SQLException e ) {
			
			e.printStackTrace ();
		}
		
		return 0;
	}

	@Override
	public List<InstagramUser> viewAllProfileDAO() {
		
		// database logic to view all profile
		
		try {
		
		// load driver
		
		Class.forName ( "org.apache.derby.jdbc.EmbeddedDriver" );
								
		// get connection to database
								
		Connection con = DriverManager.getConnection ( "jdbc:derby:d:/database/instagram", "ashutosh", "4159" );
								
		// prepare query
								
		PreparedStatement ps = con.prepareStatement ( "SELECT * FROM InstagramUser" );
						
		// execute Query
						
		ResultSet rs = ps.executeQuery ();
						
		List < InstagramUser > iul = new ArrayList < InstagramUser > ();
		
		while ( rs.next() ) {
		
			InstagramUser iu = new InstagramUser ();
		
			iu.setName ( rs.getString ( 1 ) );
			iu.setPassword ( rs.getString ( 2 ) );
			iu.setEmail ( rs.getString ( 3 ) );
			iu.setAddress ( rs.getString ( 4 ) );
						
			iul.add ( iu );
		}
					
		return iul;
		
		} catch ( ClassNotFoundException | SQLException s ) {
			
			s.printStackTrace ();
		}
		
		return null;
		
	}

	@Override
	public int updateProfileDAO ( InstagramUser iu ) {
		
			// logic to edit profile
		
		try {

			// load driver
							
			Class.forName ( "org.apache.derby.jdbc.EmbeddedDriver" );
									
			// get connection to database
									
			Connection con = DriverManager.getConnection ( "jdbc:derby:d:/database/instagram", "ashutosh", "4159" );
									
			// prepare query
			
			PreparedStatement ps;
			
			// based on integer received update query
									
			ps = con.prepareStatement ( "UPDATE InstagramUser SET NAME = '" + iu.getName () + "', PASSWORD = '" + iu.getPassword () + "', ADDRESS = '" + iu.getAddress () + "' WHERE EMAIL = '" + iu.getEmail() + "'");
			
			if ( ps.executeUpdate () > 0 ) {
				
				return 1;
			}
		
		
		} catch (SQLException | ClassNotFoundException e ) {
			
			e.printStackTrace ();			
		}
				
		return 0;
	}

}
