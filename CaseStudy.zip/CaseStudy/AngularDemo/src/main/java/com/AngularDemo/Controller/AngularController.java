package com.AngularDemo.Controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AngularDemo.DAO.DAOLayerInterface;
import com.entity.InstagramUser;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;


@RestController
@RequestMapping("angularDemo")
@CrossOrigin("*")
public class AngularController {

    @Autowired
    private DAOLayerInterface dao;    
    
    @GetMapping("/instagram")
    public List <InstagramUser> viewProfile () {
    	
    	List <InstagramUser> list = dao.viewAllProfileDAO();    	

    	return list;
    	
    }
    
    @PostMapping("/instagram")
    public String createProfile (@RequestBody InstagramUser user) {
    	
    	String s = "profile not created";
    	
    	if ( dao.createProfileDAO (user) == 1 ) {
    	
    		s = "Profile Created";
    	
    	}
    	
    	return s;
    }
    
    @DeleteMapping("/instagram/{name}")
    public void deleteProfile (@PathVariable("name") String user) {
    	
    	if ( dao.deleteProfileDAO (user) == 1 ) {    		
    		
    	}
    }
    
    @PutMapping ("/instagram")
    public void updateProfile (@RequestBody InstagramUser user) {
    	
    	if ( dao.updateProfileDAO (user) == 1 ) {    		
    		
    	}
    }
	
}
