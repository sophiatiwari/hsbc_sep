import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { InstagramServiceService } from '../instagram-service.service';

import { instagramUser } from '../instagramUser';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css']
})

export class CreateProfileComponent {

  user: instagramUser = new instagramUser ();

  constructor (
  	
  	private instagramService: InstagramServiceService  	

  ) { }


  createProfile ( data ) {

  	this.instagramService.createUser(this.user)
  	.subscribe ();

  }

}
