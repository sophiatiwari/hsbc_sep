import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { instagramUser } from './instagramUser';

import * as Rx from "rxjs/Rx";
import { from, Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class InstagramServiceService {

  private baseUrl = 'http://localhost:5001';

  constructor(private httpClient: HttpClient) {}

	getUsers(): Observable <instagramUser[]> {

		return this.httpClient.get<instagramUser[]>(this.baseUrl + '/angularDemo/instagram');
	}

	createProfile ( data ): void {


		console.log (data);
	}

	createUser (user: instagramUser): Observable<instagramUser> {

	    return this.httpClient.post<instagramUser>(this.baseUrl + '/angularDemo/instagram', user);
  	}

  	deleteUser (name: string): Observable<string> {

  		return this.httpClient.delete<string>(this.baseUrl + '/angularDemo/instagram/' + name);
  	}

  	updateUser (user: instagramUser): Observable<instagramUser> {

	    return this.httpClient.put<instagramUser>(this.baseUrl + '/angularDemo/instagram', user);
  	}

}
