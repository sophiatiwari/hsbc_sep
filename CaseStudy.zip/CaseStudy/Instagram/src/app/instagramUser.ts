export class instagramUser {
	
	name: String;
	password: String ;
	email: String;
	address: String;
}