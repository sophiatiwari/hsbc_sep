import { Component, OnInit } from '@angular/core';

import { instagramUser } from '../instagramUser';

import { HttpClient } from '@angular/common/http';

import { InstagramServiceService } from '../instagram-service.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})

export class ViewProfileComponent implements OnInit {

  list: instagramUser [];

  edit: boolean = false;
  editData: instagramUser = new instagramUser ();

  constructor(public http: HttpClient, private instagramService: InstagramServiceService ){}

  ngOnInit(): void {

  	this.viewAllProfile ();
  }

  editProfile (data: instagramUser): void {

    this.edit = true;
    Object.assign (this.editData, data);
  }

  updateProfile ( data: instagramUser ): void {

    this.edit = !this.edit;
    console.log (data);

    this.instagramService.updateUser(data)
    .subscribe ();

    this.refereshTable ();
  }


  viewAllProfile(): void {    //it is automatically called inside the ngInit()

    this.instagramService
    .getUsers()     //return the data in observable format.
    .subscribe ( data => this.list = data );   //similar to .then function
  }


  deleteProfile (name: string): void {

    this.instagramService
    .deleteUser (name)
    .subscribe();

    this.refereshTable ();
  }

  refereshTable (): void {

    this.viewAllProfile ();
  }

}